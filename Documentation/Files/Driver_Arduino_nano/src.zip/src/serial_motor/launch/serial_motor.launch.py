from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='false', description='Use simulation (Gazebo) clock if true'),
        DeclareLaunchArgument('robot_name', default_value='rUBot', description='Name of the robot'),
        DeclareLaunchArgument('serial_port', default_value='/dev/ttyACM0', description='Serial port of the Arduino'),
        DeclareLaunchArgument('baud_rate', default_value='57600', description='Baud rate for serial communication'),
        DeclareLaunchArgument('loop_rate', default_value='30', description='Main control loop rate in Hz'),
        DeclareLaunchArgument('encoder_cpr', default_value='1440', description='Counts per revolution for encoders'),

        Node(
            package='serial_motor',
            executable='motor_driver_exec',  # make sure this matches your setup.py entry point
            name='motor_driver',
            parameters=[{
                'use_sim_time': LaunchConfiguration('use_sim_time'),
                'serial_port': LaunchConfiguration('serial_port'),
                'baud_rate': LaunchConfiguration('baud_rate'),
                'loop_rate': LaunchConfiguration('loop_rate'),
                'encoder_cpr': LaunchConfiguration('encoder_cpr'),
            }],
            arguments=['-robot_name_value', LaunchConfiguration('robot_name')],
            output='screen'
        )
    ])
